<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="solid-red-09" tilewidth="32" tileheight="32" tilecount="1980" columns="60">
 <image source="solid-red-09.png" width="1920" height="1080"/>
</tileset>
